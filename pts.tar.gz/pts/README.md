# PTS tools
PTS tools includes pts_writer and pts_creator. Both will needed by **gvelo** to create and write in a pseudo terminal.

# Requirements

 - Linux OS with Kernel 4. or higher
 - gcc compiler

# Install

Download the pts and unpack to /usr/src.  Change in the directory and run: 

    make all
    make install


## Uninstall

Move in to directory /usr/src/pts and run:

    make uninstall
